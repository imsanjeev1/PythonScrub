from django.shortcuts import render,HttpResponse
from .models import Record_data

def index(request):
    import scrubadub
    text = "My cat can be contacted on example@example.com, or 1800 555-5555"
    scrb=scrubadub.clean(text)
    if request.method=="POST":
        # import sys
        # # sys.path.append("C:\Program Files\JetBrains\PyCharm 2017.2.3\debug-eggs")
        # sys.path.append("D:\pycharm-debug")
        # import pydevd
        # pydevd.settrace('localhost', port=9086, stdoutToServer=True, stderrToServer=True)
        import pandas as pd
        filename = request.FILES['data_file']
        print(">>.",filename)
        data_read=pd.read_csv(filename, encoding='utf8')
        # name = data_read["Name"]
        # address = data_read["Address"]
        # phone = data_read["Phone"]
        # email = data_read["Email"]
        column_names=list(data_read.columns)

        # check_file_exist = Record_data.objects.filter(Filepath=filename).exists()
        # print("ddddddddddd>>>",check_file_exist)
        # if check_file_exist == False:
        #     data_record = Record_data(
        #         Name=name,
        #         Address=address,
        #         Phone=phone,
        #         Email=email,
        #         Filepath=filename,
        #     )
        #     # data_record.save()
        # mydata = Record_data.objects.all()

        # data_lst=[x for x in mydata]
        # print("DAtata11111111",mydata)
        # print("DAtata",data_lst)
        # import pdb
        # pdb.set_trace()
        return render(request, "index.html", {"msg1": "File upload Successfully","column": column_names})
    return render(request, "index.html",{"msg": scrb})

def data(request):
    if request.method=="POST":
        # import sys
        # # sys.path.append("C:\Program Files\JetBrains\PyCharm 2017.2.3\debug-eggs")
        # sys.path.append("D:\pycharm-debug")
        # import pydevd
        # pydevd.settrace('localhost', port=9086, stdoutToServer=True, stderrToServer=True)
        import pandas as pd
        filename = request.FILES['data_file']
        data_read=pd.read_csv(filename)
        # iter_data = data_read.iterrows()
        # name=pd.Series(data_read["Name"]).str.cat(sep=',').split( )
        # address=pd.Series(data_read["Address"]).str.cat(sep=',')
        # phone=pd.Series(str(data_read["Phone"])).str.cat(sep=',').split( )
        # email=pd.Series(data_read["Email"]).str.cat(sep='\n')
        # name = pd.Series(data_read["Name"])
        # address = pd.Series(data_read["Address"])
        # phone = pd.Series(data_read["Phone"])
        # email = pd.Series(data_read["Email"])
        name = [x for x in data_read["Name"]]
        address = [x for x in data_read["Address"]]
        phone = [x for x in data_read["Phone"]]
        email = [x for x in data_read["Email"]]
        check_file_exist = Record_data.objects.filter(Filepath=filename).exists()
        print("ddddddddddd>>>",check_file_exist)
        if check_file_exist == False:
            data_record = Record_data(
                Name=name,
                Address=address,
                Phone=phone,
                Email=email,
                Filepath=filename,
            )
            data_record.save()
        mydata = Record_data.objects.all()

        # data_lst=[x for x in mydata]
        print("DAtata11111111",mydata)
        # print("DAtata",data_lst)
        # import pdb
        # pdb.set_trace()
        return render(request, "data.html",{'data':mydata})
    mydata = Record_data.objects.all()
    # d_data={x.Name for x in mydata}

    return render(request, "data.html",{'data':mydata})
# Create your views here.
